package com.example.inventoryapplicationenglund;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class SmsActivity extends AppCompatActivity {

    private boolean smsPermissionGranted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        Button allowButton = findViewById(R.id.allow);
        Button denyButton = findViewById(R.id.Deny);

        allowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                smsPermissionGranted = true;
                goToInventory();
            }
        });

        denyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                smsPermissionGranted = false;
                goToInventory();
            }
        });
    }

    private void goToInventory() {
        Intent intent = new Intent(SmsActivity.this, InventoryActivity.class);
        intent.putExtra("smsPermission", smsPermissionGranted); // Pass the permission status
        startActivity(intent);
        finish();
    }
}