package com.example.inventoryapplicationenglund;

public class InventoryItem {
    private int id;
    private String itemName;

    public InventoryItem(int id, String itemName) {
        this.id = id;
        this.itemName = itemName;
    }

    public int getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }
}