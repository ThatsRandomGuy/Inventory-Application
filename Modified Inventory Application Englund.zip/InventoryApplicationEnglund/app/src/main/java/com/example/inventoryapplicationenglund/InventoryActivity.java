package com.example.inventoryapplicationenglund;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.SearchView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;
    private RecyclerView itemListView;
    private EditText itemTextBox;
    private Button addItemButton, removeItemButton;
    private InventoryAdapter adapter;
    private List<InventoryItem> inventoryItems;
    private boolean smsPermission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SearchView searchView = findViewById(R.id.search_view);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
    
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        Intent intent = getIntent();
        smsPermission = intent.getBooleanExtra("smsPermission", false);

        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getWritableDatabase();

        itemListView = findViewById(R.id.itemListView);
        itemTextBox = findViewById(R.id.itemTextBox);
        addItemButton = findViewById(R.id.AddItem);
        removeItemButton = findViewById(R.id.removeItem);

        inventoryItems = new ArrayList<>();
        adapter = new InventoryAdapter(inventoryItems);
        itemListView.setLayoutManager(new LinearLayoutManager(this));
        itemListView.setAdapter(adapter);

        loadInventory();

        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem();
            }
        });

        removeItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeItem();
            }
        });
    }

    private void loadInventory() {
        inventoryItems.clear();
        Cursor cursor = db.rawQuery("SELECT * FROM inventory", null);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
                inventoryItems.add(new InventoryItem(id, itemName));
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    private void addItem() {
        String itemName = itemTextBox.getText().toString().trim();
        if (!itemName.isEmpty()) {
            db.execSQL("INSERT INTO inventory (item_name) VALUES ('" + itemName + "')");
            itemTextBox.setText("");
            loadInventory();
        } else {
            Toast.makeText(this, "Please enter an item name", Toast.LENGTH_SHORT).show();
        }
    }

    private void removeItem() {
        String itemName = itemTextBox.getText().toString().trim();
        if (!itemName.isEmpty()) {
            db.execSQL("DELETE FROM inventory WHERE item_name = '" + itemName + "'");
            itemTextBox.setText("");
            loadInventory();
        } else {
            Toast.makeText(this, "Please enter an item name to remove", Toast.LENGTH_SHORT).show();
        }
    }
}